<?php 

wp_footer(); 

?>

</div>
