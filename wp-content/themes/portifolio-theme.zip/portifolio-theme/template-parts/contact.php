<div class="row">
    <div class="col-6">
        <div class="h-100vh">
            <div class="row h-100vh post-content align-items-center">
                <div class="col-12 align-self-end">
                    <p class="contact-text-1">Get in touch</p>
                    <p class="contact-text-2">Say Hello</p>
                    <p class="contact-text-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                </div>
                <div class="col-12 align-self-stretch">
                    <?php echo do_shortcode('[contact-form-7 id="5" title="Contact form 1"]'); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-6 col-sm-6">
        <div class="featured-img">
            <img src="http://placehold.it/920x980" alt="">
        </div>
    </div>
</div>